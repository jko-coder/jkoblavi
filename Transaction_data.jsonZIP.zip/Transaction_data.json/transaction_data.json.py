sales_data=[]
csv_file = open("text_files\SalesJan2009.csv")
for line in csv_file:
    tmp_line = line.split(",")
    tmp_line[0] = tmp_line[0][1:-1]
    print(tmp_line)
    print(line)
    print(tmp_line[0])












 

 
 

