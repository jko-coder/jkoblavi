import json
json_file = open("text_files\salesjan2009.json")
config_data = json.load(json_file)
json_file.close()

print(config_data)

